// A persistent script to hold the list of urls the user doesn't want the extension to run on


var excluded_domains = [];
var test_bool = true;